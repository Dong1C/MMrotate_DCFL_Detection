_base_ = [
    '../common/mstrain_3x_coco_instance.py',
    '../_base_/models/cascade_mask_rcnn_r50_fpn.py'
]
